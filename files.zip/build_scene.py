"""
Ek command me poora LibBot scene banata hai.

    python build_scene.py                      # CoppeliaSim open, simulation STOPPED
    python build_scene.py --youbot-model "C:\\Program Files\\CoppeliaRobotics\\CoppeliaSimEdu\\models\\robots\\mobile\\KUKA YouBot.ttm"
    python build_scene.py --no-table --at -1.1,-1.73,180

Phir File > Save Scene As... Bas.

  * Wheels: CoppeliaSim ke KUKA YouBot model ke ORIGINAL mecanum wheels (asli roller
    physics), 0.8x scale = 80 mm. Source: scene me /youBot ho to wahi, warna model
    browser wali file sim.loadModel se khud load hoti hai.
  * Base ko wheels khud chalate hai (force hack nahi).
  * Arm: yaw + 3 pitch, body ke theek upar turret pe tika hua, parallel gripper
    (dynamic fingers) aur gripper pe vision sensor 'gripper_cam'.
  * Drop_Table, books conditioning.
"""
from __future__ import annotations

import argparse
import math
import os
import time

import numpy as np

import config as C
from robot_controller import RemoteAPIClient

I3 = np.eye(3)
RX90 = np.array([[1, 0, 0], [0, 0, 1], [0, -1, 0]], float)     # local z -> +y
RXM90 = np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]], float)    # local z -> -y

DARK, GREY, ORANGE, YELLOW, BLACK = ([0.13, 0.15, 0.20], [0.35, 0.37, 0.42],
                                     [0.92, 0.45, 0.06], [0.95, 0.75, 0.10],
                                     [0.06, 0.06, 0.07])


def log(m):
    print(f'[build] {m}')


def mat12(R, p):
    return [float(v) for v in np.hstack([R, np.array(p, float).reshape(3, 1)]).flatten()]


def rz(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], float)


_SET_ORDER = None


def set_matrix(sim, h, R, p, rel=-1):
    """setObjectMatrix ka argument order CoppeliaSim versions me alag hai."""
    global _SET_ORDER
    M = mat12(R, p)
    if _SET_ORDER in (None, 'new'):
        try:
            sim.setObjectMatrix(h, M, rel)
            _SET_ORDER = 'new'
            return
        except Exception:
            if _SET_ORDER == 'new':
                raise
    sim.setObjectMatrix(h, rel, M)
    _SET_ORDER = 'old'


def get_matrix(sim, h, rel=-1):
    m = np.array(sim.getObjectMatrix(h, rel), float).reshape(3, 4)
    return m[:, :3], m[:, 3]


def shape(sim, kind, size, p, color, R=I3, name=None, respondable=True,
          mass=None, parent=None, static=False):
    prim = {'box': sim.primitiveshape_cuboid, 'cyl': sim.primitiveshape_cylinder,
            'sph': sim.primitiveshape_spheroid}[kind]
    h = sim.createPrimitiveShape(prim, [float(s) for s in size], 0)
    set_matrix(sim, h, R, p)
    sim.setShapeColor(h, None, sim.colorcomponent_ambient_diffuse, list(color))
    sim.setObjectInt32Param(h, sim.shapeintparam_static, 1 if static else 0)
    sim.setObjectInt32Param(h, sim.shapeintparam_respondable, 1 if respondable else 0)
    if mass is not None:
        sim.setShapeMass(h, float(mass))
    if name:
        sim.setObjectAlias(h, name)
    if parent is not None:
        sim.setObjectParent(h, parent, True)
    return h


def joint(sim, kind, p, R, name, lo, hi, force, parent, mode='position'):
    jt = sim.joint_revolute_subtype if kind == 'rev' else sim.joint_prismatic_subtype
    jm = getattr(sim, 'jointmode_dynamic', None)
    if jm is None:
        jm = sim.jointmode_force
    h = sim.createJoint(jt, jm, 0, [0.03, 0.008])
    set_matrix(sim, h, R, p)
    sim.setObjectAlias(h, name)
    if lo is not None:
        sim.setJointInterval(h, False, [float(lo), float(hi - lo)])
    elif kind == 'rev':
        sim.setJointInterval(h, True, [-math.pi, 2 * math.pi])      # cyclic: wheel ghoomta rahe
    ctrl = {'position': 'jointdynctrl_position', 'velocity': 'jointdynctrl_velocity'}[mode]
    try:
        sim.setObjectInt32Param(h, sim.jointintparam_dynctrlmode, getattr(sim, ctrl))
    except Exception:
        pass
    for prm in ('jointintparam_motor_enabled', 'jointintparam_ctrl_enabled'):
        try:
            sim.setObjectInt32Param(h, getattr(sim, prm), 1)
        except Exception:
            pass
    sim.setJointTargetForce(h, float(force))
    sim.setObjectParent(h, parent, True)
    return h


def set_friction(sim, h, mu):
    ok = 0
    for nm in ('bullet_body_friction', 'ode_body_friction', 'vortex_body_primlinearfriction',
               'newton_body_staticfriction', 'newton_body_kineticfriction',
               'bulletfloatparam_friction', 'odefloatparam_friction'):
        pid = getattr(sim, nm, None)
        if pid is None:
            continue
        try:
            sim.setEngineFloatParam(pid, h, float(mu))
            ok += 1
        except Exception:
            pass
    return ok


SPECIAL = ('objectspecialproperty_collidable', 'objectspecialproperty_measurable',
           'objectspecialproperty_detectable', 'objectspecialproperty_renderable')


def make_detectable(sim, h):
    v = 0
    for nm in SPECIAL:
        v |= getattr(sim, nm, 0)
    try:
        sim.setObjectSpecialProperty(h, v)
    except Exception:
        pass


def tree_of(sim, root):
    """Root + saare descendants, bina duplicate ke (getObjectsInTree base ko
    khud include karta hai)."""
    return list(dict.fromkeys([root] + list(sim.getObjectsInTree(root, sim.handle_all, 0))))


def remove_tree(sim, path):
    try:
        h = sim.getObject(path)
    except Exception:
        return False
    handles = tree_of(sim, h)
    try:
        sim.removeObjects(handles)
    except Exception:
        # ek ek karke, bachhe pehle - koi handle pehle hi hat gaya ho to skip
        for x in reversed(handles):
            try:
                sim.removeObjects([x])
            except Exception:
                pass
    return True


# ---------------------------------------------------------------------------
def build_body(sim):
    bx, by, bz = C.BODY_SIZE
    zc = C.BODY_BOTTOM_Z + bz / 2
    parts = [
        shape(sim, 'box', C.BODY_SIZE, (0, 0, zc), DARK),
        shape(sim, 'box', (bx * 0.88, by * 0.82, 0.006), (0, 0, C.BODY_TOP_Z + 0.003), GREY),
        shape(sim, 'box', (0.012, by, bz * 0.62), (bx / 2 - 0.004, 0, zc), ORANGE),
        shape(sim, 'box', (0.012, by, bz * 0.62), (-bx / 2 + 0.004, 0, zc), ORANGE),
        shape(sim, 'cyl', (0.05, 0.05, 0.035), (-0.10, 0, C.BODY_TOP_Z + 0.0235), BLACK),
    ]
    body = sim.groupShapes(parts)
    sim.setObjectAlias(body, C.ROBOT_NAME)
    sim.setObjectInt32Param(body, sim.shapeintparam_static, 0)
    sim.setObjectInt32Param(body, sim.shapeintparam_respondable, 1)
    sim.setShapeMass(body, C.BODY_MASS)
    make_detectable(sim, body)
    ref = sim.createDummy(0.02)
    set_matrix(sim, ref, I3, (0, 0, 0))
    sim.setObjectAlias(ref, 'ref')
    sim.setObjectParent(ref, body, True)
    log(f'Body {bx*100:.0f}x{by*100:.0f}x{bz*100:.0f} cm, {C.BODY_MASS} kg, bottom at {C.BODY_BOTTOM_Z*100:.1f} cm')
    return body


def youbot_source(sim, model_arg):
    """Original mecanum wheels kahan se lene hai: scene ka /youBot, warna model file."""
    try:
        h = sim.getObject('/youBot')
        log("Wheels scene ke /youBot se le raha hoon.")
        return h, False
    except Exception:
        pass
    cands = [model_arg or C.YOUBOT_MODEL]
    try:
        app = sim.getStringParam(sim.stringparam_application_path)
        cands.append(os.path.join(app, 'models', 'robots', 'mobile', 'KUKA YouBot.ttm'))
    except Exception:
        pass
    cands += [r'C:\Program Files\CoppeliaRobotics\CoppeliaSimEdu\models\robots\mobile\KUKA YouBot.ttm',
              r'C:\Program Files\CoppeliaRobotics\CoppeliaSimPlayer\models\robots\mobile\KUKA YouBot.ttm',
              r'C:\Program Files\CoppeliaRobotics\CoppeliaSimPro\models\robots\mobile\KUKA YouBot.ttm',
              'models/robots/mobile/KUKA YouBot.ttm']
    tried = []
    for pth in [c for c in cands if c]:
        try:
            h = sim.loadModel(pth)
            log(f'KUKA YouBot model load hua: {pth}')
            return h, True
        except Exception as e:
            tried.append(f'    {pth}  ({str(e)[:60]})')
    raise RuntimeError(
        'KUKA YouBot model nahi mila. Do tarike:\n'
        '  A) CoppeliaSim ke Model browser (left) me  Robots > Mobile > KUKA YouBot  ko scene me\n'
        '     drag-drop karo, phir ye script dobara chalao (wo isse wheels le ke hata dega).\n'
        '  B) python build_scene.py --youbot-model "<poori path>\\KUKA YouBot.ttm"\n'
        'Maine ye paths try kiye:\n' + '\n'.join(tried))


def alias_map(sim, root):
    m = {}
    for h in tree_of(sim, root):
        m.setdefault(sim.getObjectAlias(h), h)
    return m


def forward_frame(sim, names):
    """youBot ka saaf forward frame: x = ref se arm mount ki taraf, z = upar."""
    Rr, pr = get_matrix(sim, names['youBot_ref'])
    pa = np.array(sim.getObjectPosition(names['arm_joint_1'], -1))
    f = pa[:2] - pr[:2]
    f = f / np.linalg.norm(f) if np.linalg.norm(f) > 1e-4 else np.array([1.0, 0.0])
    F = np.eye(4)
    F[:3, 0] = [f[0], f[1], 0.0]
    F[:3, 1] = [-f[1], f[0], 0.0]
    F[:3, 2] = [0.0, 0.0, 1.0]
    F[:3, 3] = pr
    return F


def clone_subtree(sim, root):
    handles = tree_of(sim, root)
    new = list(sim.copyPasteObjects(handles, 0))
    want = sim.getObjectAlias(root)
    for h in new:                         # root ka clone dhoondho (order par bharosa nahi)
        if sim.getObjectAlias(h) == want:
            return h, new
    return new[0], new


def build_wheels(sim, body, names):
    scale = C.WHEEL_DIAMETER / C.WHEEL_SOURCE_DIAMETER
    F = forward_frame(sim, names)
    invR = np.linalg.inv(F)[:3, :3]
    corners = {'fl': (C.WHEEL_X, C.WHEEL_Y), 'fr': (C.WHEEL_X, -C.WHEEL_Y),
               'rl': (-C.WHEEL_X, C.WHEEL_Y), 'rr': (-C.WHEEL_X, -C.WHEEL_Y)}
    for key, (cx, cy) in corners.items():
        src = names[f'rollingJoint_{key}']
        Rs, _ = get_matrix(sim, src)
        R_rel = invR @ Rs               # robot frame me orientation: roller handedness bachti hai
        root, allnew = clone_subtree(sim, src)
        sim.scaleObjects(allnew, scale, True)
        sim.setObjectParent(root, body, True)
        set_matrix(sim, root, R_rel, (cx, cy, C.WHEEL_RADIUS))
        sim.setObjectAlias(root, f'rollingJoint_{key}')
        try:
            sim.setObjectInt32Param(root, sim.jointintparam_dynctrlmode, sim.jointdynctrl_velocity)
        except Exception:
            pass
        sim.setJointTargetForce(root, float(C.WHEEL_FORCE))
        sim.setJointTargetVelocity(root, 0.0)
    log(f'4 ORIGINAL mecanum wheels (youBot, {scale:.2f}x -> {C.WHEEL_DIAMETER*1000:.0f} mm), '
        f'wheelbase {C.WHEEL_X*200:.0f} cm, track {C.WHEEL_Y*200:.0f} cm')


def build_arm(sim, body):
    z0, zs = C.Z_YAW, C.Z_SHOULDER
    L1, L2, L3 = C.ARM_L1, C.ARM_L2, C.ARM_L3
    lim = C.ARM_LIMITS
    F = C.ARM_JOINT_FORCE
    yaw = joint(sim, 'rev', (0, 0, z0), I3, 'arm_yaw', *lim['yaw'], F, body)
    turret = shape(sim, 'cyl', (0.09, 0.09, C.TURRET_H), (0, 0, z0 + C.TURRET_H / 2),
                   ORANGE, mass=0.3, respondable=False, parent=yaw)
    # sim_q = -th, isliye limits ulti
    sh = joint(sim, 'rev', (0, 0, zs), RX90, 'arm_shoulder',
               -lim['th1'][1], -lim['th1'][0], F, turret)
    l1 = shape(sim, 'box', (L1, 0.032, 0.040), (L1 / 2, 0, zs), GREY, mass=0.15,
               respondable=False, parent=sh)
    el = joint(sim, 'rev', (L1, 0, zs), RX90, 'arm_elbow',
               -lim['th2'][1], -lim['th2'][0], F, l1)
    l2 = shape(sim, 'box', (L2, 0.028, 0.036), (L1 + L2 / 2, 0, zs), ORANGE, mass=0.12,
               respondable=False, parent=el)
    wr = joint(sim, 'rev', (L1 + L2, 0, zs), RX90, 'arm_wrist',
               -lim['th3'][1], -lim['th3'][0], F * 0.6, l2)
    px = L1 + L2 + 0.045
    palm_parts = [shape(sim, 'box', (0.09, 0.16, 0.025), (px, 0, zs), GREY),
                  shape(sim, 'box', (0.034, 0.045, 0.022), (px + 0.012, 0, zs + 0.0235), BLACK)]
    palm = sim.groupShapes(palm_parts)       # camera housing palm ke saath ek hi body
    sim.setObjectAlias(palm, 'palm')
    sim.setObjectInt32Param(palm, sim.shapeintparam_static, 0)
    sim.setObjectInt32Param(palm, sim.shapeintparam_respondable, 1)
    sim.setShapeMass(palm, 0.17)
    sim.setObjectParent(palm, wr, True)
    # gripper camera: palm ke upar, aage (+x) dekhti hui. VisionSensor local +z me dekhta hai, +y up.
    Rcam = np.array([[0, 0, 1], [1, 0, 0], [0, 1, 0]], float)
    cam = sim.createVisionSensor(2, [C.CAM_RES[0], C.CAM_RES[1], 0, 0],
                                 [0.01, 3.0, math.radians(C.CAM_FOV_DEG), 0.02, 0, 0, 0, 0, 0, 0, 0])
    set_matrix(sim, cam, Rcam, (px + 0.03, 0, zs + 0.0235))
    sim.setObjectAlias(cam, 'gripper_cam')
    sim.setObjectParent(cam, palm, True)
    tipx = L1 + L2 + L3
    tip = sim.createDummy(0.012)
    set_matrix(sim, tip, I3, (tipx, 0, zs))
    sim.setObjectAlias(tip, 'tip')
    sim.setObjectParent(tip, palm, True)
    for name, sgn, Rj in (('finger_l', +1, RX90), ('finger_r', -1, RXM90)):
        p = (tipx, sgn * (C.FINGER_T / 2), zs)
        fj = joint(sim, 'pri', p, Rj, name, 0.0, C.GRIP_OPEN, C.GRIP_FORCE, palm)
        f = shape(sim, 'box', (C.FINGER_LEN, C.FINGER_T, C.FINGER_H), p, YELLOW,
                  mass=0.03, respondable=True, parent=fj)
        set_friction(sim, f, C.FINGER_FRICTION)
    log(f'4-DOF arm: L1 {L1*100:.0f} + L2 {L2*100:.0f} cm, gripper tip {L3*100:.0f} cm '
        f'from wrist, shoulder z={zs:.3f} m, turret sits on body top z={z0:.3f} m')


def place_robot(sim, body, x, y, yaw):
    R0, p0 = get_matrix(sim, body)
    Rn = rz(yaw) @ R0
    pn = rz(yaw) @ p0 + np.array([x, y, 0.002])
    set_matrix(sim, body, Rn, pn)


# ---------------------------------------------------------------------------
def build_table(sim):
    remove_tree(sim, C.DROP_TABLE)
    try:
        sp = sim.getObjectPosition(sim.getObject(C.DROP_SPOT), -1)
        cx, cy = sp[0], sp[1]
    except Exception:
        cx, cy = 0.55, -1.60
        log('Drop_Spot nahi mila, default (0.55, -1.60) use kiya.')
    d, w, t = C.TABLE_SIZE
    top = C.TABLE_TOP_Z
    parts = [shape(sim, 'box', (d, w, t), (cx, cy, top - t / 2), C.TABLE_COLOR)]
    lh = top - t
    for sx in (-1, 1):
        for sy in (-1, 1):
            parts.append(shape(sim, 'box', (C.TABLE_LEG, C.TABLE_LEG, lh),
                               (cx + sx * (d / 2 - C.TABLE_LEG), cy + sy * (w / 2 - C.TABLE_LEG), lh / 2),
                               [0.35, 0.24, 0.14]))
    table = sim.groupShapes(parts)
    sim.setObjectAlias(table, 'Drop_Table')
    sim.setObjectInt32Param(table, sim.shapeintparam_static, 1)
    sim.setObjectInt32Param(table, sim.shapeintparam_respondable, 1)
    make_detectable(sim, table)
    set_friction(sim, table, 0.8)
    log(f'Drop_Table at ({cx:.2f}, {cy:.2f}), top {top:.2f} m, {d*100:.0f}x{w*100:.0f} cm')


def condition_books(sim):
    for code in C.CATALOG:
        h = None
        for p in (f'/{C.SOURCE_SHELF}/{code}', f'/{code}'):
            try:
                h = sim.getObject(p)
                break
            except Exception:
                pass
        if h is None:
            log(f"WARNING: book '{code}' scene me nahi mili.")
            continue
        sim.setObjectInt32Param(h, sim.shapeintparam_static, 0)
        sim.setObjectInt32Param(h, sim.shapeintparam_respondable, 1)
        sim.setShapeMass(h, C.BOOK_MASS)
        make_detectable(sim, h)
        set_friction(sim, h, C.BOOK_FRICTION)
        sim.resetDynamicObject(h)
        pos = sim.getObjectPosition(h, -1)
        log(f"  {code}: z={pos[2]:.3f}  mass {C.BOOK_MASS} kg, friction {C.BOOK_FRICTION}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--no-table', action='store_true')
    ap.add_argument('--at', default=None, help='x,y,heading_deg')
    ap.add_argument('--youbot-model', default=None, help='KUKA YouBot.ttm ki poori path')
    args = ap.parse_args()

    sim = RemoteAPIClient().require('sim')
    if sim.getSimulationState() != sim.simulation_stopped:
        log('Simulation stop kar raha hoon.')
        sim.stopSimulation()
        while sim.getSimulationState() != sim.simulation_stopped:
            time.sleep(0.1)

    if remove_tree(sim, '/' + C.ROBOT_NAME):
        log('Purana LibBot hata diya.')

    src, loaded = youbot_source(sim, args.youbot_model)
    names = alias_map(sim, src)
    missing = [n for n in ('youBot_ref', 'arm_joint_1') + tuple(f'rollingJoint_{k}' for k in ('fl', 'fr', 'rl', 'rr'))
               if n not in names]
    if missing:
        raise RuntimeError(f'YouBot model me ye parts nahi mile: {missing}')

    x, y, yaw = C.SPAWN
    if args.at:
        a = [float(v) for v in args.at.split(',')]
        x, y, yaw = a[0], a[1], math.radians(a[2]) if len(a) > 2 else yaw

    body = build_body(sim)
    build_wheels(sim, body, names)
    build_arm(sim, body)
    place_robot(sim, body, x, y, yaw)
    log(f'Robot spawn: ({x:.2f}, {y:.2f}), heading {math.degrees(yaw):.0f} deg')

    sim.removeObjects(tree_of(sim, src))
    log('YouBot (wheels ka source) hata diya.' + (' [model file se load hua tha]' if loaded else ''))

    try:
        sim.setFloatParam(sim.floatparam_simulation_time_step, C.SIM_TIME_STEP)
    except Exception:
        log('Time step manually set karo: Simulation settings -> dt = 10 ms')
    if not args.no_table:
        build_table(sim)
    condition_books(sim)
    sim.resetDynamicObject(body)

    print()
    log('Ho gaya. CoppeliaSim me File > Save Scene As... karo, phir:')
    log('  Simulation START  ->  python check_setup.py')


if __name__ == '__main__':
    main()
