"""
CoppeliaSim ke bina poore controller ka test. Ek chhota fake sim hai jo
robot_controller jo API calls karta hai wahi deta hai (force-driven base, joints,
books, weld). Isse logic bugs (crash, galat order, unreachable targets) sim
chalane se pehle pakde jaate hai. Physics ka test nahi - wo check_setup.py karta hai.

    python selftest.py
"""
from __future__ import annotations
import math, sys, types
import numpy as np
import config as C
import robot_controller as RC
from kinematics import arm_fk, segment_hits_wall, body_velocity_from_wheels


class FakeClient:
    def __init__(self, sim): self.sim = sim
    def require(self, _): return self.sim
    def step(self): self.sim._step()


class FakeSim:
    handle_all = -2; simulation_stopped = 0; shapeintparam_static = 1

    def __init__(self):
        self.t = 0.0; self.dt = C.SIM_TIME_STEP
        self.x, self.y, self.yaw = C.SPAWN
        self.v = np.zeros(2); self.w = 0.0
        self.wv = {11: 0.0, 12: 0.0, 13: 0.0, 14: 0.0}
        self.axis = {11: 1.0, 12: -1.0, 13: 1.0, 14: -1.0}   # right wheels ka axis ulta (clone jaisa)
        self.names = {1: 'LibBot', 2: 'ref', 3: 'palm', 4: 'tip', 5: 'arm_yaw', 6: 'arm_shoulder',
                      7: 'arm_elbow', 8: 'arm_wrist', 9: 'finger_l', 10: 'finger_r',
                      11: 'rollingJoint_fl', 12: 'rollingJoint_fr', 13: 'rollingJoint_rl', 14: 'rollingJoint_rr'}
        self.jt = {j: 0.0 for j in (5, 6, 7, 8, 9, 10)}
        self.jtgt = dict(self.jt)
        self.books = {20: ['AC', np.array([-2.2, -1.75, 0.2686])], 21: ['EDC', np.array([-2.2, -1.95, 0.0949])],
                      22: ['NT', np.array([-2.2, -1.75, 0.0947])], 23: ['ADC', np.array([-2.2, -1.55, 0.0949])]}
        self.parent = {}; self.offset = {}
        self.fixed = {30: np.array([-2.2, -1.75, 0.1]), 31: np.array([-2.33, 1.15, 0.1]),
                      32: np.array([0.55, -1.60, 0.06]), 33: np.array([0.55, -1.60, 0.0])}
        self.paths = {'/LibBot': 1, '/Cupboard_1': 30, '/Cupboard_2': 31, '/Drop_Table': 32, '/Drop_Spot': 33}
        for h, (n, _) in self.books.items():
            self.paths[f'/Cupboard_1/{n}'] = h
        self.min_wall_gap = 9.0; self.log_calls = 0

    # ---- physics step
    def _step(self):
        std = {k: self.axis[h] * self.wv[h] for k, h in zip(('fl', 'fr', 'rl', 'rr'), (11, 12, 13, 14))}
        bx, by, bw = body_velocity_from_wheels(std)
        c, sn = math.cos(self.yaw), math.sin(self.yaw)
        self.v = np.array([c * bx - sn * by, sn * bx + c * by]); self.w = bw
        self.x += self.v[0] * self.dt; self.y += self.v[1] * self.dt; self.yaw += self.w * self.dt
        self.t += self.dt
        for (x0, x1, y0, y1) in C.WALLS:       # footprint ka wall se gap
            dx = max(x0 - self.x, 0, self.x - x1); dy = max(y0 - self.y, 0, self.y - y1)
            self.min_wall_gap = min(self.min_wall_gap, math.hypot(dx, dy) - C.BUMPER)
        for j in self.jt: self.jt[j] = self.jtgt[j]

    # ---- helpers
    def _ref_m(self):
        c, s = math.cos(self.yaw), math.sin(self.yaw)
        return [c, -s, 0, self.x, s, c, 0, self.y, 0, 0, 1, 0]

    def _q(self): return [self.jt[5], -self.jt[6], -self.jt[7], -self.jt[8]]

    def _tip(self):
        p = arm_fk(self._q()); c, s = math.cos(self.yaw), math.sin(self.yaw)
        return np.array([self.x + c * p[0] - s * p[1], self.y + s * p[0] + c * p[1], p[2]])

    def _bookpos(self, h):
        return self._tip() + self.offset[h] if self.parent.get(h) == 3 else self.books[h][1]

    # ---- API
    def getSimulationState(self): return 1
    def startSimulation(self): pass
    def setStepping(self, v): pass
    def getObject(self, p):
        if p in self.paths: return self.paths[p]
        raise KeyError(p)
    def getObjectAlias(self, h, o=-1): return self.names[h]
    def getObjectsInTree(self, h, t, o): return [k for k in self.names if k != 1]
    def getObjectMatrix(self, h, rel):
        if h in self.axis and rel == 2:
            return [1, 0, 0, 0, 0, 0, self.axis[h], 0, 0, 1, 0, 0]
        return self._ref_m()
    def getObjectVelocity(self, h): return [[self.v[0], self.v[1], 0.0], [0, 0, self.w]]
    def getObjectPosition(self, h, rel):
        if h in (1, 2): return [self.x, self.y, 0.05]
        if h == 4: return list(self._tip())
        if h in self.books: return list(self._bookpos(h))
        return list(self.fixed[h])
    def setJointTargetVelocity(self, h, v): self.wv[h] = v
    def setJointTargetForce(self, h, f): pass
    def setJointTargetPosition(self, h, v): self.jtgt[h] = v
    def getJointPosition(self, h):
        if h in (9, 10):
            if self.jtgt[h] < 0.01:
                for bh in self.books:
                    if self.parent.get(bh) is None and np.linalg.norm(self._bookpos(bh) - self._tip()) < 0.06:
                        return 0.019
                return 0.0
        return self.jt[h]
    def setObjectParent(self, h, par, keep):
        if par == 3:
            self.offset[h] = self.books[h][1] - self._tip(); self.parent[h] = 3
        else:
            self.books[h][1] = self._bookpos(h).copy(); self.parent[h] = None
            p = self.books[h][1]; t = self.fixed[32]     # table pe girti hai
            if abs(p[0] - t[0]) < 0.16 and abs(p[1] - t[1]) < 0.31: p[2] = C.TABLE_TOP_Z + C.BOOK_SIZE[2] / 2
    def setObjectInt32Param(self, h, p, v): pass
    def resetDynamicObject(self, h): pass


def main():
    sim = FakeSim()
    RC.RemoteAPIClient = lambda: FakeClient(sim)
    ok = True

    def check(name, cond, extra=''):
        nonlocal ok
        ok &= bool(cond); print(f'  [{"PASS" if cond else "FAIL"}] {name} {extra}')

    print('== construct ==')
    bot = RC.LibBot(verbose=False)
    check('init, no crash', True)
    check('carry pose reached', np.linalg.norm(bot.arm_tip_base() - np.array(C.CARRY_TIP)) < 1e-3)

    print('== base ==')
    check('calibrate_base', bot.calibrate_base())
    check('drive signs untouched (axis sign auto-handled)', list(C.DRIVE_SIGNS) == [1.0, 1.0, 1.0])

    print('== fetch NT -> table ==')
    check('go_to_book', bot.go_to_book('NT'),
          f'pose=({sim.x:.2f},{sim.y:.2f}) yaw={math.degrees(sim.yaw):.0f}')
    bumper_gap = (sim.x - sim.books[22][1][0]) - C.BUMPER - C.BOOK_SIZE[0] / 2
    check('bumper clear of book face', bumper_gap > 0.05, f'gap={bumper_gap:.3f} m')
    check('pick_book', bot.pick_book('NT'))
    check('holding NT', bot.is_grasped and bot.held_book == 'NT')
    check('go_to_table', bot.go_to_table(), f'pose=({sim.x:.2f},{sim.y:.2f})')
    check('place_on_table', bot.place_on_table())
    z = sim.books[22][1][2]
    check('book at table height', abs(z - (C.TABLE_TOP_Z + 0.08)) < 0.02, f'z={z:.3f}')
    check('gripper empty', not bot.is_grasped)

    print('== return NT -> Cupboard_2 ==')
    check('shelve_book', bot.shelve_book('NT'))
    pn = sim.books[22][1]
    check('book at Cupboard_2', np.linalg.norm(pn[:2] - sim.fixed[31][:2]) < 0.12, f'pos={np.round(pn, 2)}')

    print('== high shelf (AC) ==')
    check('go_to_book AC', bot.go_to_book('AC'))
    check('pick AC', bot.pick_book('AC'))
    check('go_to_table + place (slot 2)', bot.go_to_table() and bot.place_on_table())

    print('== safety / routing ==')
    check('never hit a wall', sim.min_wall_gap > 0.05, f'min gap={sim.min_wall_gap:.3f} m')
    check('table->Cupboard_2 straight line would hit wall',
          segment_hits_wall((0.22, -1.60), (-1.99, 1.15)))
    check('shutdown', (bot.shutdown() or True))
    print('\nALL PASSED' if ok else '\nFAILURES ABOVE')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
