"""
Gripper camera ka live feed. Simulation ▶ chal rahi ho.   python camera_view.py     (q = quit)
"""
import cv2
import numpy as np
from robot_controller import RemoteAPIClient
import config as C

sim = RemoteAPIClient().require('sim')
body = sim.getObject('/' + C.ROBOT_NAME)
cam = next((h for h in [body] + list(sim.getObjectsInTree(body, sim.handle_all, 0))
            if sim.getObjectAlias(h) == 'gripper_cam'), None)
if cam is None:
    raise SystemExit('gripper_cam nahi mili - python build_scene.py chalao')
print('Live feed (q = quit)')
while True:
    img, res = sim.getVisionSensorImg(cam)
    frame = np.frombuffer(img, np.uint8).reshape(res[1], res[0], 3)
    frame = cv2.cvtColor(cv2.flip(frame, 0), cv2.COLOR_RGB2BGR)
    cv2.imshow('LibBot gripper camera', frame)
    if cv2.waitKey(30) & 0xFF == ord('q'):
        break
cv2.destroyAllWindows()
