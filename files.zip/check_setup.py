"""
Pre-flight check. Simulation START karke chalao:   python check_setup.py

1. Robot sahi bana hai? (saare joints/handles)
2. FK model bhi sim ke asli tip se match karta hai? (axis/sign convention yahin pakda jaata hai)
3. Arm bina sagging ke carry pose hold karta hai? Body tilt to nahi hoti?
4. Har book / table / Cupboard_2 reachable hai (har waypoint ke saath)?
5. Raaste me deewar to nahi?
"""
from __future__ import annotations
import math
import numpy as np
import config as C
from kinematics import arm_fk, arm_ik, route, segment_hits_wall
from robot_controller import LibBot


def main() -> int:
    bad = []
    def line(tag, msg):
        print(f'  [{tag}] {msg}')
        if tag != 'OK':
            bad.append(msg)

    bot = LibBot(verbose=False)
    sim = bot.sim
    print('\n== 1. ROBOT ==')
    line('OK', f"handles ok: {len(bot.h)} parts, wheels {C.WHEEL_DIAMETER*1000:.0f} mm, "
               f"footprint {C.FOOTPRINT*100:.0f}x{C.FOOTPRINT*100:.0f} cm")

    print('\n== 2. FK vs asli sim tip (convention check) ==')
    worst = 0.0
    for q in ([0, 1.2, -2.0, 0.8], [0.5, 1.0, -2.2, 1.2], [-0.5, 1.5, -2.4, 0.9], [0, 0.6, -1.0, 0.4]):
        bot._arm_set(q)
        bot.sleep(2.0)
        got = bot.world_to_base(bot.tip_world())
        err = float(np.linalg.norm(got - arm_fk(q)))
        worst = max(worst, err)
        print(f'     q={np.round(q, 2)}  model={np.round(arm_fk(q), 3)}  sim={np.round(got, 3)}  err={err*1000:.1f} mm')
    if worst < 0.015:
        line('OK', f'FK matches sim (worst {worst*1000:.1f} mm)')
    else:
        line('FAIL', f'FK sim se {worst*1000:.0f} mm alag. Joint axis/sign ulta hai - '
                     'build_scene.py dobara chalao, ya mujhe ye output bhejo.')

    print('\n== 3. HOLD / STABILITY ==')
    bot.arm_carry(1.5)
    err = np.linalg.norm(bot.arm_tip_base() - np.array(C.CARRY_TIP))
    sag = float(np.linalg.norm(bot.world_to_base(bot.tip_world()) - np.array(C.CARRY_TIP)))
    line('OK' if sag < 0.02 else 'FAIL', f'carry pose hold: sim tip {sag*1000:.1f} mm off (joint PID/force)')
    M = np.array(sim.getObjectMatrix(bot.ref, -1)).reshape(3, 4)
    tilt = math.degrees(math.acos(max(-1, min(1, M[2, 2]))))
    line('OK' if tilt < 3 else 'FAIL', f'body tilt with arm out: {tilt:.2f} deg')
    x0, y0, _ = bot.pose()
    bot.sleep(2.0)
    x1, y1, _ = bot.pose()
    drift = math.hypot(x1 - x0, y1 - y0)
    line('OK' if drift < 0.01 else 'FAIL', f'parked drift in 2 s: {drift*1000:.1f} mm')

    print('\n== 3b. WHEELS (original mecanum) ==')
    badw = []
    for k in ('fl', 'fr', 'rl', 'rr'):
        pb = bot.world_to_base(sim.getObjectPosition(bot.wheels[k], -1))
        exp = np.array([(1 if k[0] == 'f' else -1) * C.WHEEL_X, (1 if k[1] == 'l' else -1) * C.WHEEL_Y,
                        C.WHEEL_RADIUS])
        off = float(np.linalg.norm(pb - exp))
        print(f'     {k}: pos={np.round(pb, 3)}  expected={np.round(exp, 3)}  axis_sign={bot.wheel_sign[k]:+.0f}')
        if off > 0.02:
            badw.append(f'{k}: {off*100:.1f} cm apni jagah se hat gaya')
    line('OK' if not badw else 'FAIL', 'sab 4 wheels apni jagah pe hai' if not badw else '; '.join(badw))
    line('OK' if bot.cam else 'FAIL', 'gripper camera (gripper_cam) mili' if bot.cam
         else 'gripper_cam nahi mili - build_scene.py dobara chalao')
    if bot.cam:
        img = bot.camera_image()
        line('OK' if img is not None and img.size else 'FAIL',
             f'camera image aa rahi hai {None if img is None else img.shape}  (python camera_view.py se live dekho)')

    print('\n== 3c. BASE DRIVE (asli motion, ~5 s) ==')
    x0, y0, t0 = bot.pose()
    for nm, cmd, idx, thr in (('forward 0.2 m/s', (0.2, 0, 0), 0, 0.10),
                              ('strafe-left 0.15 m/s', (0, 0.15, 0), 1, 0.08),
                              ('rotate-ccw 0.6 rad/s', (0, 0, 0.6), 2, 0.3)):
        a = bot.pose()
        for _ in range(int(1.5 / bot.dt)):
            bot._drive_step(*cmd)
        bot.stop_base()
        b = bot.pose()
        d = np.array([b[0] - a[0], b[1] - a[1]])
        res = [float(d @ [math.cos(a[2]), math.sin(a[2])]),
               float(d @ [-math.sin(a[2]), math.cos(a[2])]),
               float((b[2] - a[2] + math.pi) % (2 * math.pi) - math.pi)]
        unit = 'rad' if idx == 2 else 'm'
        line('OK' if res[idx] > thr else 'FAIL',
             f'{nm}: moved {res[idx]:+.3f} {unit} in the right direction (need > {thr})'
             + ('' if res[idx] > thr else '  -> python main_system.py --calibrate --no-auth chalao (sign auto-fix karta hai)'))
    bot.navigate(x0, y0, t0)
    xb, yb, _ = bot.pose()
    line('OK' if math.hypot(xb - x0, yb - y0) < 0.05 else 'FAIL',
         f'wapas start pe aaya, error {math.hypot(xb - x0, yb - y0)*100:.1f} cm')

    print('\n== 4. REACH (har waypoint) ==')
    front1 = np.array([*C.FRONT[C.SOURCE_SHELF], 0.0])
    for code in C.CATALOG:
        h = bot.find(code)
        if h == -1:
            line('FAIL', f"book '{code}' scene me nahi mili")
            continue
        p = np.array(sim.getObjectPosition(h, -1))
        stand = p + front1 * C.APPROACH_STANDOFF
        g = np.array([C.APPROACH_STANDOFF - C.GRASP_DEPTH, 0, p[2] + C.GRASP_Z_OFFSET])
        pts = {'grasp': g, 'pre': g - [C.PRE_GRASP_OFFSET, 0, 0], 'lift': g + [0, 0, C.LIFT_HEIGHT],
               'pull': g - [C.PRE_GRASP_OFFSET, 0, -C.LIFT_HEIGHT]}
        miss = [k for k, v in pts.items() if arm_ik(v, 0.0) is None]
        gap = C.APPROACH_STANDOFF - C.BOOK_SIZE[0] / 2 - C.BUMPER
        line('OK' if not miss else 'FAIL',
             f'{code:<4} z={p[2]:.3f}  stand=({stand[0]:.2f},{stand[1]:.2f})  bumper gap {gap*100:.0f} cm'
             + (f'  UNREACHABLE: {miss}' if miss else ''))

    t = bot.find(C.DROP_TABLE)
    if t == -1:
        line('FAIL', 'Drop_Table nahi hai - python build_scene.py chalao')
    else:
        inset = C.TABLE_SIZE[0] / 2 - C.TABLE_INSET
        bc = C.TABLE_TOP_Z + C.BOOK_SIZE[2] / 2 + C.RELEASE_GAP
        d = C.TABLE_STANDOFF - inset - C.GRASP_DEPTH
        miss = [k for k, v in {'place': (d, 0, bc + C.GRASP_Z_OFFSET),
                               'pre-place': (d - C.PRE_GRASP_OFFSET, 0, bc + C.GRASP_Z_OFFSET + 0.03),
                               'return-pickup': (C.PICK_TABLE_STANDOFF - C.GRASP_DEPTH, 0,
                                                 C.TABLE_TOP_Z + C.BOOK_SIZE[2] / 2 + C.GRASP_Z_OFFSET)}.items()
                if arm_ik(v, 0.0) is None]
        gap = C.TABLE_STANDOFF - C.TABLE_SIZE[0] / 2 - C.BUMPER
        line('OK' if not miss else 'FAIL',
             f'table: top {C.TABLE_TOP_Z} m, bumper gap {gap*100:.0f} cm' + (f'  UNREACHABLE {miss}' if miss else ''))

    c2 = bot.find(C.RETURN_SHELF)
    if c2 == -1:
        line('FAIL', 'Cupboard_2 nahi mila')
    else:
        ok = arm_ik((C.APPROACH_STANDOFF - C.GRASP_DEPTH, 0, C.RETURN_SHELF_PLACE_Z + C.GRASP_Z_OFFSET), 0.0)
        line('OK' if ok else 'FAIL', f'Cupboard_2 drop at z={C.RETURN_SHELF_PLACE_Z} m '
             '(agar book shelf ke andar nahi ghusti to config.RETURN_SHELF_PLACE_Z badlo)')

    print('\n== 5. ROUTES ==')
    if t != -1 and c2 != -1:
        pt = sim.getObjectPosition(t, -1)
        pc = sim.getObjectPosition(c2, -1)
        a = (pt[0] + C.FRONT['Drop_Table'][0] * C.TABLE_STANDOFF, pt[1])
        b = (pc[0] + C.FRONT[C.RETURN_SHELF][0] * C.APPROACH_STANDOFF, pc[1])
        r = route(a, b)
        line('OK', f'table -> Cupboard_2: {"seedha" if len(r) == 1 else "HUB ke through"} '
                   f'({"direct raasta deewar se takrata" if segment_hits_wall(a, b) else "direct clear"})')

    bot.go_home()
    bot.shutdown()
    print('\n' + ('ALL CLEAR - ab python main_system.py --mode worker' if not bad
                  else f'{len(bad)} PROBLEM(S) - upar FAIL lines dekho aur mujhe output paste karo'))
    return 0 if not bad else 1


if __name__ == '__main__':
    raise SystemExit(main())
